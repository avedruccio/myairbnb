import {Component, OnInit, ViewChild} from '@angular/core';
import {Router} from '@angular/router';
import { AuthService } from '../services/auth.service';
import { AlertController } from '@ionic/angular';

import { User } from '../model/user';

@Component({
  selector: 'app-login',
  templateUrl: './login.page.html',
  styleUrls: ['./login.page.scss'],
})
export class LoginPage implements OnInit {
  stringa: string;

  @ViewChild('email',{static: false}) email;
  @ViewChild('password',{static: false}) password;
  constructor(public alertController: AlertController, private Auth: AuthService,private router: Router) { }

  ngOnInit() {
  } 

async popup(){
  const alert = await this.alertController.create({
    header: 'ATTENZIONE',
    message: 'email o password non corretta',
    buttons: ['OK'],
});

                         await alert.present();
                         const result = await alert.onDidDismiss();
                         console.log(result);

}


    signIn() {

      console.log(this.email.value)
    this.Auth.checkuser(this.email.value, this.password.value).subscribe(data => {
      this.stringa = JSON.stringify(data);
      if (this.stringa !== 'null') {
        const user = sessionStorage.setItem('username',this.email.value);
        this.router.navigate(['firstpage']);
      

      }else{
       this.popup();
      }
    });
    }

} 
