import { CommentoService } from './../services/commento.service';
import { AfterContentInit, Component, OnInit, ViewChild, ElementRef } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Commento } from '../model/commento';
import { CommentoRisposta } from '../model/commentorisposta';
import { CommentoripostaService } from '../services/commentoriposta.service';
import { AlertController } from '@ionic/angular';
declare var google;



@Component({
  selector: 'app-details',
  templateUrl: './details.page.html',
  styleUrls: ['./details.page.scss'],
})
  export class DetailsPage implements OnInit, AfterContentInit {
   map;
    commento: Commento = new Commento();
    submitted = false;
   user: String;


    public numstelle: string;
    public idapp: string;
    public ci: string;
    public co: string;
    public nome: string;
    public proponente: string;
    public citta: string;
    public indirizzo: string;
    public descrizione: string;
    public posti: string;
    public image: string;
    public prezzogiornaliero: string;
    public lat: number;
    public lng: number;
    risposte: CommentoRisposta[];
    commentorisposta: CommentoRisposta  = new CommentoRisposta();
   commenti: Commento[];

   @ViewChild('mapElement', {static: true})  mapElement;

    constructor(public alertController: AlertController, private commentoripsostaservice: CommentoripostaService, private commentoservice: CommentoService, private router: Router, private route: ActivatedRoute) {
    this.idapp = this.route.snapshot.paramMap.get('id') ;
    this.ci = this.route.snapshot.paramMap.get('ci') ;
    this.co = this.route.snapshot.paramMap.get('co') ;
    this.nome = this.route.snapshot.paramMap.get('nome') ;
    this.citta = this.route.snapshot.paramMap.get('citta') ;
    this.indirizzo = this.route.snapshot.paramMap.get('indirizzo') ;
    this.descrizione = this.route.snapshot.paramMap.get('descrizione') ;
    this.posti = this.route.snapshot.paramMap.get('posti') ;
    this.image = this.route.snapshot.paramMap.get('image') ;
    this.proponente = this.route.snapshot.paramMap.get('proponente') ;
    this.prezzogiornaliero = this.route.snapshot.paramMap.get('prezzogiornaliero') ;
    this.lng = +this.indirizzo.split('-')[1];
    this.lat = +this.indirizzo.split('-')[0];
  }

  ngOnInit() {
    this.user = sessionStorage.getItem('username');

    this.commentoservice.SearchCommentoforTypeofService(1).subscribe( data => {
      this.commenti = data;    });

    this.commentoripsostaservice.getRisposteList().subscribe( data1 => {
        this.risposte = data1;    });

  }


    ngAfterContentInit(): void {
      this.map = new google.maps.Map(
      this.mapElement.nativeElement,
          {
            center: {lat: -34.397, lng: 150.644},
            zoom: 8
          });

      const pos = {
            lat: this.lat,
            lng: this.lng
          };

      this.map.setCenter(pos);


      const marker = new google.maps.Marker({
            position: pos, // marker position
            map: this.map, // map already created
            title: 'Hello World!',

          });
      const contentString = this.nome;
      const infowindow = new google.maps.InfoWindow({
        content: contentString,
        maxWidth: 400
      });
      marker.addListener('click', function() {
        infowindow.open(this.map, marker);
      });

    }

async booking(idapp, ci, co, nome, citta, indirizzo, descrizione, posti, image, prezzogiornaliero, proponente) {
  if ( this.user == 'GUEST') {
     const alert = await this.alertController.create({
      header: 'ATTENZIONE',
      message: 'Per effettuare la prenotazione è necessario effettuare la registrazione',
      buttons: ['OK'],
  });

                           await alert.present();
                           const result = await alert.onDidDismiss();
                           console.log(result);

  } else if (this.ci == 'empty') { const alert = await this.alertController.create({
      header: 'ATTENZIONE',
      message: 'Verifica la disponibilità nelle date che cerchi',
      buttons: ['OK'],
  });

      await alert.present();
      const result = await alert.onDidDismiss();
      console.log(result);
     } else {
  this.router.navigate(['prenota-appartamento', idapp, ci, co, nome, citta, indirizzo, descrizione, posti, image, prezzogiornaliero, proponente]);
  }
}

newCommeno(): void {
  this.submitted = false;
  this.commento = new Commento();
}


checkValue(event) { this.numstelle = event.detail.value; }

async AddComment() {
  if(this.user=="GUEST"){   const alert = await this.alertController.create({
    header: 'ATTENZIONE',
    message: 'Per inserire un commento è necessario effettuare la registrazione',
    buttons: ['OK'],
});

    await alert.present();
    const result = await alert.onDidDismiss();
    console.log(result);
  } 
  else if (this.numstelle==undefined){
    const alert = await this.alertController.create({
      header: 'ATTENZIONE',
      message: 'Aggiungi numero di stelle',
      buttons: ['OK'],
  });

      await alert.present();
      const result = await alert.onDidDismiss();
      console.log(result);
  }else {
  this.commento.mailuser = '' + this.user;
  this.commento.idtiposervizio = 1;
  this.commento.id_servizio_commentato = +this.idapp;
  this.commento.stelle = +this.numstelle;
  console.log(this.numstelle);
  this.commentoservice.createCommento(this.commento)
    .subscribe(
      data => {
        console.log(data);
        this.submitted = true;
      },
      error => console.log(error));
  this.commento = new Commento();
}}




}
