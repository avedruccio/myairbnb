import { MenuPage } from './menu/menu.page';
import { NgModule } from '@angular/core';
import { PreloadAllModules, RouterModule, Routes } from '@angular/router';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { IonicModule } from '@ionic/angular';

const routes: Routes = [
  { path: '', redirectTo: 'home', pathMatch: 'full' },
  { path: 'home', loadChildren: './home/home.module#HomePageModule' },
  { path: 'details/:id/:ci/:co/:nome/:citta/:indirizzo/:descrizione/:posti/:image/:prezzogiornaliero/:proponente', loadChildren: './details/details.module#DetailsPageModule' },
  { path: 'firstpage', loadChildren: './firstpage/firstpage.module#FirstpagePageModule' },
  { path: 'login', loadChildren: './login/login.module#LoginPageModule' },
  { path: 'register', loadChildren: './register/register.module#RegisterPageModule' },
  { path: 'autodetails/:idauto/:ci/:co/:marca/:targa/:citta/:indirizzo/:modello/:posti/:carburante/:image/:prezzogiornaliero/:proponente', loadChildren: './autodetails/autodetails.module#AutodetailsPageModule' },
  { path: 'escursionedetails/:ci/:co/:id/:citta/:descrizione/:durata/:nome/:posti/:prezzogiornaliero/:image/:indirizzo/:indirizzoarr/:carr/:proponente', loadChildren: './escursionedetails/escursionedetails.module#EscursionedetailsPageModule' },
  { path: 'resultapp/:place/:ci/:co/:ospiti', loadChildren: './result-appartamento/result-appartamento.module#ResultAppartamentoPageModule' },
  { path: 'result-escursione/:place/:ci/:co/:ospiti', loadChildren: './result-escursione/result-escursione.module#ResultEscursionePageModule' },
  { path: 'result-auto/:place/:ci/:co/:ospiti', loadChildren: './result-auto/result-auto.module#ResultAutoPageModule' },
  { path: 'prenota-appartamento/:idapp/:ci/:co/:nome/:citta/:indirizzo/:descrizione/:posti/:image/:prezzogiornaliero/:proponente', loadChildren: './prenota-appartamento/prenota-appartamento.module#PrenotaAppartamentoPageModule' },
  { path: 'prenota-auto/:idauto/:ci/:co/:marca/:targa/:citta/:indirizzo/:modello/:posti/:carburante/:image/:prezzogiornaliero/:proponente', loadChildren: './prenota-auto/prenota-auto.module#PrenotaAutoPageModule' },
  { path: 'prenota-escursione/:idesc/:ci/:co/:citta/:descrizione/:durata/:nome/:posti/:prezzo/:image/:indirizzo/:indirizzoarr/:carr/:proponente', loadChildren: './prenota-escursione/prenota-escursione.module#PrenotaEscursionePageModule' },
  { path: 'menu',
  component:MenuPage,
   children:[{
     path:'first',
     loadChildren:'./firstpage/firstpage.module#FirstpagePageModule'
   },{
    path:'second',
    loadChildren:'./register/register.module#RegisterPageModule'
  }]
  },
  { path: 'prenotazioni', loadChildren: './prenotazioni/prenotazioni.module#PrenotazioniPageModule' },
  { path: 'marker', loadChildren: './marker/marker.module#MarkerPageModule' },
  { path: 'temporanea', loadChildren: './temporanea/temporanea.module#TemporaneaPageModule' },
  { path: 'mappa', loadChildren: './mappa/mappa.module#MappaPageModule' },
  { path: 'proposte', loadChildren: './proposte/proposte.module#PropostePageModule' },
  { path: 'appartamentoproposto/:id/:nome/:citta/:ci/:co/:ospiti/:imageprop', loadChildren: './appartamentoproposto/appartamentoproposto.module#AppartamentopropostoPageModule' },
  { path: 'escursioneproposta/:id/:nome/:cittapartenza/:cittaarrivo/:ci/:co/:ospiti/:imageprop', loadChildren: './escursioneproposta/escursioneproposta.module#EscursionepropostaPageModule' },
  { path: 'autoproposta/:id/:marca/:modello/:targa/:carburante/:place/:ci/:co/:ospiti/:imageprop', loadChildren: './autoproposta/autoproposta.module#AutopropostaPageModule' },
  { path: 'view-notifica', loadChildren: './view-notifica/view-notifica.module#ViewNotificaPageModule' },
  { path: 'serviziodetails/:ci/:co/:id/:citta/:descrizione/:durata/:nome/:posti/:prezzogiornaliero/:image/:indirizzo/:indirizzoarr/:proponente/:idtiposervizio', loadChildren: './serviziodetails/serviziodetails.module#ServiziodetailsPageModule' },
  { path: 'result-servizio/:place/:ci/:co/:ospiti/:nomeservizio/:idtiposervizio', loadChildren: './result-servizio/result-servizio.module#ResultServizioPageModule' },
  { path: 'prenota-servizio/:idesc/:ci/:co/:citta/:descrizione/:durata/:nome/:posti/:prezzo/:image/:indirizzo/:indirizzoarr/:proponente/:idtiposervizio', loadChildren: './prenota-servizio/prenota-servizio.module#PrenotaServizioPageModule' },
  { path: 'servizioproposto/:idserv/:nome/:citta/:ci/:co/:ospiti/:idtiposervizio/:imageprop', loadChildren: './servizioproposto/servizioproposto.module#ServiziopropostoPageModule' },


];

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    RouterModule.forRoot(routes, { preloadingStrategy: PreloadAllModules })
  ],
  declarations:[MenuPage],
  exports: [RouterModule]
})
export class AppRoutingModule { }
