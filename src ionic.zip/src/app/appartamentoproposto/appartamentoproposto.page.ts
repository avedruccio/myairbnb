import { CommentoripostaService } from './../services/commentoriposta.service';
import { CommentoRisposta } from './../model/commentorisposta';
import { Component, OnInit } from '@angular/core';
import { Apartment } from '../model/apartment';
import { Router, ActivatedRoute } from '@angular/router';
import { ApartmentService } from '../services/apartment.service';
import { CommentoService } from '../services/commento.service';
import { Commento } from '../model/commento';

@Component({
  selector: 'app-appartamentoproposto',
  templateUrl: './appartamentoproposto.page.html',
  styleUrls: ['./appartamentoproposto.page.scss'],
})
export class AppartamentopropostoPage implements OnInit {
  public idapp: string;
  public nome: string;
  public citta: string;
  public ci: string;
  public co: string;
  public ospiti: string;
  submitted = false;
  commentorisposta:CommentoRisposta  = new CommentoRisposta();imageprop: string;
;
  commenti:Commento[];
  appartamenti: Apartment[];
  appartamento: Apartment;
  risposte:CommentoRisposta[];
  idcomm: string;
  user:String;

   
  constructor(private commentoripsostaservice:CommentoripostaService,private commentoservice: CommentoService,private router: Router,private route: ActivatedRoute,private appartamentoService: ApartmentService) {
      this.idapp =this.route.snapshot.paramMap.get('id') ;
      this.nome =this.route.snapshot.paramMap.get('nome') ;
      this.citta =this.route.snapshot.paramMap.get('citta') ;
      this.ci =this.route.snapshot.paramMap.get('ci') ;
      this.co =this.route.snapshot.paramMap.get('co') ;
      this.ospiti =this.route.snapshot.paramMap.get('ospiti') ;
      this.imageprop =this.route.snapshot.paramMap.get('imageprop') ;
      
   }

   
  ngOnInit() {
    this.user=sessionStorage.getItem('username')

    this.commentoservice.SearchCommentoforTypeofService(1).subscribe( data => {
      this.commenti = data;    })


    this.commentoripsostaservice.getRisposteList().subscribe( data1 => {
      this.risposte =data1;    })
  }


  rispcommento(comm){
    console.log(this.user,this.idapp,comm.id)
    this.commentorisposta.mailuser=this.user;
    this.commentorisposta.idtiposervizio=1;
    this.commentorisposta.id_servizio_commentato=+this.idapp
    this.commentorisposta.id_commento_risp=+comm.id
    this.commentoripsostaservice.createCommentoRisposta(this.commentorisposta)
      
    .subscribe(
        data => {
          console.log(data);
          this.submitted = true;
        },
        error => console.log(error));
    this.commentorisposta = new CommentoRisposta();
  }

  
  

}
