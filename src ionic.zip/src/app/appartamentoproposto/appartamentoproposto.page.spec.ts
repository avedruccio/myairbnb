import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AppartamentopropostoPage } from './appartamentoproposto.page';

describe('AppartamentopropostoPage', () => {
  let component: AppartamentopropostoPage;
  let fixture: ComponentFixture<AppartamentopropostoPage>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AppartamentopropostoPage ],
      schemas: [CUSTOM_ELEMENTS_SCHEMA],
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AppartamentopropostoPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
