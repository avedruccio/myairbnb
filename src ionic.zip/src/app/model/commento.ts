export class Commento {

  id: number
  stelle:number
  testo:String
  mailuser:String
  idtiposervizio:number
  id_servizio_commentato:number
}

