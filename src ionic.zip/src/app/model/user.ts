export class User {
    id: number;
    name: string;
    cognome: string;
    mail: string;
    telefono: string;
    datadinascita: Date;
    password: string;

}
