export class CommentoRisposta {
  id: number
  testo:String
  mailuser:String
  idtiposervizio:number
  id_servizio_commentato:number
  id_commento_risp:number
}

