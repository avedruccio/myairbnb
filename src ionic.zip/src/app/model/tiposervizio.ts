export class Tiposervizio {
  id: number;
  nome: string;
  descrizione: string;
  icona: string;
  bcolor: string;


}
