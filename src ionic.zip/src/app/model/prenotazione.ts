export class Prenotazione { 
    id:number
    id_tiposervizio: number
    mailuser:String
    checkin: string
    checkout:string
    totale:number
    metodopagamento:String
    id_servizio_prenotato:string
  };
