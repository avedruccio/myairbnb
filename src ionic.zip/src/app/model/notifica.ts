export class Notifica {
    id: number;
    titolo: string;
    emailutente: string;
    vista: string;


}