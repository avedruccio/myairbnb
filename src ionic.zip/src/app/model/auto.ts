export class Auto {

  id: number;
  citta: string;
  marca: string;
  modello: string;
  targa: string;
  carburante: string;
  prezzogiornaliero: number;
  indirizzo: string;
  posti: number;
  iniziodisponibilita: Date;
  finedisponibiliita: Date;
  evasa: number;
  image:string;
}

