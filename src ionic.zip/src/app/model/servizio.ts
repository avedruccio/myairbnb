export class Servizio {
  id: number;
  citta: string;
  nome: string;
  descrizione: string;
  prezzogiornaliero: number;
  indirizzo: string;
  indirizzoarr: string;
  carr: string;
  durata: string;
  posti: number;
  iniziodisponibilita: Date;
  finedisponibilita: Date;
  evasa: number;
  image: string;
  proponente: string;
  nomeservizio: string;
}
