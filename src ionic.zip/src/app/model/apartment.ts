export interface Apartment {
    id:number
    citta:string
    nome:string
    descrizione:string
    prezzo_giornaliero: number
    latitudine: string
    longitudine: string
    posti:string
    inizio_disponibilita: Date
    fine_disponibilita:Date
    evasa:string
    image:string
    proponente:string
  };
