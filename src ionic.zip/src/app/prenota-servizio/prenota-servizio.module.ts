import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Routes, RouterModule } from '@angular/router';

import { IonicModule } from '@ionic/angular';

import { PrenotaServizioPage } from './prenota-servizio.page';

const routes: Routes = [
  {
    path: '',
    component: PrenotaServizioPage
  }
];

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    RouterModule.forChild(routes)
  ],
  declarations: [PrenotaServizioPage]
})
export class PrenotaServizioPageModule {}
