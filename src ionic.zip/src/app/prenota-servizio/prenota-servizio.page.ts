import { Component, OnInit } from '@angular/core';
import { Notifica } from '../model/notifica';
import { Prenotazione } from '../model/prenotazione';
import { PrenotazioneService } from '../services/prenotazione.service';
import { Router, ActivatedRoute } from '@angular/router';
import { AlertController } from '@ionic/angular';
import { NotificaService } from '../services/notifica.service';
import moment from 'moment';

@Component({
  selector: 'app-prenota-servizio',
  templateUrl: './prenota-servizio.page.html',
  styleUrls: ['./prenota-servizio.page.scss'],
})
export class PrenotaServizioPage implements OnInit {

  prenotazione: Prenotazione = new Prenotazione();
  notifica: Notifica = new Notifica();
  submitted = false;
  public idesc:string
  public citta: string;
  public descrizione: string;
  public durata: string;
  public nome: string;
  public posti: string;  
  public prezzogiornaliero: string;
  public image: string;
  public proponente: string;
  public indirizzo:string;
  public indirizzoarr:string;
  public carr:string;
  public  acquirente :string
  public  ci : string; //Passare a Date
  public  co : string; //Passare a Date
  public prodotto:number
  firstDate: any; 
  secondDate: any;
  diffInDays: number;



 product:any
  constructor(public alertController: AlertController,private prenotazioneService: PrenotazioneService,private router: Router,private route: ActivatedRoute, private  notificaservice: NotificaService) {
    this.idesc =this.route.snapshot.paramMap.get('idesc') ;
    this.proponente =this.route.snapshot.paramMap.get('proponente') ;
    this.ci =this.route.snapshot.paramMap.get('ci') ;
    this.co =this.route.snapshot.paramMap.get('co') ;
    this.citta =this.route.snapshot.paramMap.get('citta') ;
    this.descrizione =this.route.snapshot.paramMap.get('descrizione') ; 
    this.durata =this.route.snapshot.paramMap.get('durata') ;
    this.nome =this.route.snapshot.paramMap.get('nome') ;
    this.posti =this.route.snapshot.paramMap.get('posti') ;
    this.prezzogiornaliero =this.route.snapshot.paramMap.get('prezzo') ;
    this.image =this.route.snapshot.paramMap.get('image') ;
    this.indirizzo =this.route.snapshot.paramMap.get('indirizzo') ;
    this.indirizzoarr =this.route.snapshot.paramMap.get('indirizzoarr') ;
    this.carr ="empty"
    this.firstDate = moment(this.route.snapshot.paramMap.get('co'));
    this.secondDate = moment(this.route.snapshot.paramMap.get('ci'));
    this.diffInDays = Math.abs(this.firstDate.diff(this.secondDate, 'days')); 
    this.prodotto=this.diffInDays*(+this.prezzogiornaliero)
    
   }

  ngOnInit() {
    this.acquirente=sessionStorage.getItem('username')
  }
  async ok(){const alert = await this.alertController.create({
    header: 'COMPLIMENTI',
    message: 'Prenotazione effettuata con successo',
    buttons: ['OK'],
});

    await alert.present();
    const result = await alert.onDidDismiss();
    console.log(result);}
  save() {
   
    
    this.prenotazione.mailuser=""+this.acquirente;
    this.prenotazione.checkin=this.ci;
    this.prenotazione.checkout=this.co;
    this.prenotazione.metodopagamento="carta di credito";
    this.prenotazione.id_tiposervizio=4;
    this.prenotazione.id_servizio_prenotato=this.idesc;
    this.prenotazione.totale=this.prodotto;
    this.prenotazioneService.createPrenotazione(this.prenotazione)
      .subscribe(
        data => {
          console.log(data);
          this.submitted = true;
          this.ok();        },
        error => console.log(error));
    this.prenotazione = new Prenotazione();
  }





  createNotificaPrenotazioneEscursione() {
    this.notifica.emailutente = this.proponente;
    this.notifica.vista = 'assets/image/book.png';
    console.log(this.proponente)
    this.notifica.titolo = '" ' + this.nome + ' " è stato prenotato da '+ this.acquirente;
  
    this.notificaservice.createNotifica(this.notifica)
      .subscribe(
        data => {
          console.log(data);
          this.submitted = true;
        },
        error => console.log(error));
    this.notifica = new Notifica();  }






}