import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PrenotaServizioPage } from './prenota-servizio.page';

describe('PrenotaServizioPage', () => {
  let component: PrenotaServizioPage;
  let fixture: ComponentFixture<PrenotaServizioPage>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PrenotaServizioPage ],
      schemas: [CUSTOM_ELEMENTS_SCHEMA],
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PrenotaServizioPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
