import { ServizioService } from './../services/servizio.service';
import { Servizio } from './../model/servizio';
import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { EscursioneService } from '../services/escursione.service';

@Component({
  selector: 'app-result-servizio',
  templateUrl: './result-servizio.page.html',
  styleUrls: ['./result-servizio.page.scss'],
})
export class ResultServizioPage implements OnInit {
  stringa:string;

  public place: string;
  public ci: string;
  public co: string;
  public ospiti: string;

  servizi: Servizio[];
  servizio: Servizio;
  nomeservizio: string;
  idtiposervizio: string;
  constructor(private router: Router,private route: ActivatedRoute,private servizioService: ServizioService) {
  
      this.place =this.route.snapshot.paramMap.get('place') ;
      this.ci =this.route.snapshot.paramMap.get('ci') ;
      this.co =this.route.snapshot.paramMap.get('co') ;
      this.ospiti =this.route.snapshot.paramMap.get('ospiti') ;
      this.nomeservizio =this.route.snapshot.paramMap.get('nomeservizio') ;
      this.idtiposervizio =this.route.snapshot.paramMap.get('idtiposervizio') ;
   }

  ngOnInit() {
    this.servizio = {} as Servizio;

    this.servizioService.getServizioByCittaAndNomeservizio(this.place,this.nomeservizio).subscribe( data => {
      this.servizi = data;
    })
  }
 
  
  getServizio(data1){
    this.router.navigate(["serviziodetails/",this.ci,this.co,data1.id,data1.citta,data1.descrizione,data1.durata,data1.nome,data1.posti,data1.prezzogiornaliero,data1.image,data1.indirizzo,data1.indirizzoarr,data1.proponente,this.idtiposervizio]);
  }

}
