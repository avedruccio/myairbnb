import {AfterViewInit, Component, ElementRef, OnInit, ViewChild, AfterContentInit} from '@angular/core';
import {FormBuilder, FormGroup, Validators} from '@angular/forms';
declare var google;
@Component({
  selector: 'app-marker',
  templateUrl: './marker.page.html',
  styleUrls: ['./marker.page.scss'],
})

  export class MarkerPage implements OnInit {
  
    constructor(private fb: FormBuilder) {
    }
    ngOnInit() {
    }
 
    }
     
