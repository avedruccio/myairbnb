import { Component, OnInit } from '@angular/core';
import { Auto } from '../model/auto';
import { Router, ActivatedRoute } from '@angular/router';
import { AutoService } from '../services/auto.service';

@Component({
  selector: 'app-result-auto',
  templateUrl: './result-auto.page.html',
  styleUrls: ['./result-auto.page.scss'],
})
export class ResultAutoPage implements OnInit {
  stringa:string;

  public place: string;
  public ci: string;
  public co: string;
  public ospiti: string;

  automobili: Auto[];
  automobile: Auto;
  constructor(private router: Router,private route: ActivatedRoute,private autoService: AutoService) {

      this.place =this.route.snapshot.paramMap.get('place') ;
      this.ci =this.route.snapshot.paramMap.get('ci') ;
      this.co =this.route.snapshot.paramMap.get('co') ;
      this.ospiti =this.route.snapshot.paramMap.get('ospiti') ;
     
      
   }

  ngOnInit() {
    this.automobile = {} as Auto;

    this.autoService.searchAuto(this.place).subscribe( data => {
      this.automobili = data;
    })
  }
 
  
getAuto(data2){
  /*console.log(data2.marca);
  console.log(data2.modello);
  console.log(data2.posti);
  console.log(data2.prezzogiornaliero);
  console.log(data2.citta);
  console.log(data2.carburante);
  console.log("questo è id :"+data2.id)
  console.log(this.ci)
  console.log(this.co)
  console.log(data2.indirizzo)
  console.log(data2.targa);*/
  this.router.navigate(["autodetails/",data2.id,this.ci,this.co,data2.marca,data2.targa,data2.citta,data2.indirizzo,data2.modello,data2.posti,data2.carburante,data2.image,data2.prezzogiornaliero,data2.proponente]);
}
}
