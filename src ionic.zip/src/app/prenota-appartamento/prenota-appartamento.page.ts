import { Component, OnInit, ViewChild } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import moment from 'moment';
import { PrenotazioneService } from '../services/prenotazione.service';
import { Prenotazione } from '../model/prenotazione';
import { NotificaService } from '../services/notifica.service';
import { AlertController } from '@ionic/angular';
import { Notifica } from '../model/notifica';

@Component({
  selector: 'app-prenota-appartamento',
  templateUrl: './prenota-appartamento.page.html',
  styleUrls: ['./prenota-appartamento.page.scss'],
})
export class PrenotaAppartamentoPage implements OnInit {
  prenotazione: Prenotazione = new Prenotazione();
  submitted = false;
  public nome: string;
  public citta: string;
  public descrizione: string;
  public posti: string;
  public image: string;
  public indirizzo:string;
  public prezzogiornaliero: string;
  public  acquirente :string
  public  ci :Date
  public  co :Date
  public idapp:string
  public prodotto:number
  public proponente:string
  notifica: Notifica = new Notifica();
  firstDate: any;
  secondDate: any;
  diffInDays: number;

 product:any

  constructor(public alertController: AlertController,private prenotazioneService: PrenotazioneService,private router: Router,private route: ActivatedRoute, private  notificaservice: NotificaService) {
    this.idapp =this.route.snapshot.paramMap.get('idapp') ;
    this.proponente =this.route.snapshot.paramMap.get('proponente') ;
    this.ci =this.route.snapshot.paramMap.get('ci') ;
    this.co =this.route.snapshot.paramMap.get('co') ;
    this.nome =this.route.snapshot.paramMap.get('nome') ;
    this.citta =this.route.snapshot.paramMap.get('citta') ;
    this.indirizzo =this.route.snapshot.paramMap.get('indirizzo') ;
    this.descrizione =this.route.snapshot.paramMap.get('descrizione') ;
    this.posti =this.route.snapshot.paramMap.get('posti') ;
    this.image =this.route.snapshot.paramMap.get('image') ;
    this.prezzogiornaliero =this.route.snapshot.paramMap.get('prezzogiornaliero') ;
    this.firstDate = moment(this.route.snapshot.paramMap.get('co'));
    this.secondDate = moment(this.route.snapshot.paramMap.get('ci'));
    this.diffInDays = Math.abs(this.firstDate.diff(this.secondDate, 'days'));
    this.prodotto=this.diffInDays*(+this.prezzogiornaliero)
  }

  ngOnInit() {
    this.acquirente=sessionStorage.getItem('username')
  }

async ok(){const alert = await this.alertController.create({
    header: 'COMPLIMENTI',
    message: 'Prenotazione effettuata con successo',
    buttons: ['OK'],
});

    await alert.present();
    const result = await alert.onDidDismiss();
    console.log(result);}

  save() {


    this.prenotazione.mailuser=""+this.acquirente;
    this.prenotazione.checkin=this.ci;
    this.prenotazione.checkout=this.co;
    this.prenotazione.metodopagamento="carta di credito";
    this.prenotazione.id_tiposervizio=1;
    this.prenotazione.id_servizio_prenotato=this.idapp;
    this.prenotazione.totale=this.prodotto;
    this.prenotazioneService.createPrenotazione(this.prenotazione)
      .subscribe(
        data => {
          console.log(data);
          this.submitted = true;
          this.ok();

        },
        error => console.log(error));
    this.prenotazione = new Prenotazione();
  }

 


  createNotificaAffittoAlloggi() {
    this.notifica.emailutente = this.proponente;
    this.notifica.titolo = '' + 'Il tuo appartamento " ' + this.nome + ' " a ' + this.citta + ' in ' + this.indirizzo + ' è stato Prenotato dal '+this.ci+' al ' +this.co+' da '+ this.acquirente;
    this.notifica.vista = 'assets/image/book.png';
    this.notificaservice.createNotifica(this.notifica)
      .subscribe(
        data => {
          console.log(data);
          this.submitted = true;
        },
        error => console.log(error));
    this.notifica = new Notifica();  }





}
