import { Component, OnInit } from '@angular/core';
import { Escursione } from '../model/escursione';
import { Router, ActivatedRoute } from '@angular/router';
import { EscursioneService } from '../services/escursione.service';

@Component({
  selector: 'app-result-escursione',
  templateUrl: './result-escursione.page.html',
  styleUrls: ['./result-escursione.page.scss'],
})
export class ResultEscursionePage implements OnInit {
  stringa:string;

  public place: string;
  public ci: string;
  public co: string;
  public ospiti: string;

  escursioni: Escursione[];
  escursione: Escursione;
  constructor(private router: Router,private route: ActivatedRoute,private escursioneService: EscursioneService) {
  
      this.place =this.route.snapshot.paramMap.get('place') ;
      this.ci =this.route.snapshot.paramMap.get('ci') ;
      this.co =this.route.snapshot.paramMap.get('co') ;
      this.ospiti =this.route.snapshot.paramMap.get('ospiti') ;
     
      
   }

  ngOnInit() {
    this.escursione = {} as Escursione;

    this.escursioneService.searchEscursione(this.place).subscribe( data => {
      this.escursioni = data;
    })
  }
 
  
  getEscursione(data1){
  
    console.log(data1.id);
    console.log(data1.citta);

    console.log(data1.indirizzo);
    console.log(data1.indirizzoarr);
    console.log(data1.descrizione);
    console.log(data1.prezzogiornaliero);
    console.log(data1.nome);
    console.log(data1.durata);
    this.router.navigate(["escursionedetails/",this.ci,this.co,data1.id,data1.citta,data1.descrizione,data1.durata,data1.nome,data1.posti,data1.prezzogiornaliero,data1.image,data1.indirizzo,data1.indirizzoarr,"empty",data1.proponente]);
  }

}
