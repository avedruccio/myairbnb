import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Notifica } from '../model/notifica';
@Injectable({
  providedIn: 'root'
})
export class NotificaService {

  private baseUrl = 'http://localhost:8080/api/notificas';
  private baseUrl99 = 'http://localhost:8080/api/notificas/count/no';
  private baseUrl1 = 'http://localhost:8080/api/notificas/evasa/1';
  private baseUrl2 = 'http://localhost:8080/api/notificas/evasa/0';
  private baseUrl3 = 'http://localhost:8080/api/notificas/citta/';
  private baseUrl4 = 'http://localhost:8080/api/notificas/mail';


  constructor(private http: HttpClient) { }

  getNotifica(id: number): Observable<any> {
    return this.http.get(`${this.baseUrl}/${id}`);
  }

  getNotificaUser(proponente: string): Observable<any> {
    return this.http.get(`${this.baseUrl4}/${proponente}`);
  }

  getNotificaCount(): Observable<any> {
    return this.http.get(this.baseUrl99);
  }


  createNotifica(notifica: any): Observable<any> {
    console.log(notifica);
    return this.http.post(this.baseUrl, notifica);
  }

  updateNotifica(id: number, value: any): Observable<any> {
    return this.http.put(`${this.baseUrl}/${id}`, value);
  }



  deleteNotifica(id: number): Observable<any> {
    return this.http.delete(`${this.baseUrl}/${id}`);
  }

  getNotificasList(): Observable<any> {
    return this.http.get(this.baseUrl1);
  }

  getNotificanonevasa(): Observable<any> {
    return this.http.get(this.baseUrl2);
  }


  getNotificasByAge(age: string): Observable<any> {
    return this.http.get(`${this.baseUrl}/age/${age}`);
  }

  deleteAll(): Observable<any> {
    return this.http.delete(this.baseUrl);
  }
}
