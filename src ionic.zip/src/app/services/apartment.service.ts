import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Apartment } from '../model/apartment';

@Injectable({
  providedIn: 'root'
})
export class ApartmentService {

  apartaments : Apartment[];
  url='http://localhost:8080/api/customers/evasa/1'
  url2='http://localhost:8080/api/customers/citta/'
  url3='http://localhost:8080/api/customers'
  url4='http://localhost:8080/api/customers/proponente/'
  constructor(private http: HttpClient) { }
 
 
    getAppartamenti(): Observable<Apartment[]> {
      return this.http.get<Apartment[]>(this.url)
  }

  getAppartamentibyId(id:string): Observable<any> {
    return this.http.get(`${this.url3}/${id}`);
  
}

  searchApartment(citta: string): Observable<Apartment[]> {
    return this.http.get<Apartment[]>(this.url2+citta);
  }
  
  getAppartamentibyProponente(proponente: string): Observable<Apartment[]> {
    return this.http.get<Apartment[]>(this.url4+proponente);
  }



}
