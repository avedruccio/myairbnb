import { Escursione } from './../model/escursione';
import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class EscursioneService {

  private baseUrl = 'http://localhost:8080/api/escursiones';
  private baseUrl1 = 'http://localhost:8080/api/escursiones/evasa/1';
  private baseUrl2 = 'http://localhost:8080/api/escursiones/evasa/0';
  private baseUrl3 = 'http://localhost:8080/api/escursiones/citta/';
  private url4='http://localhost:8080/api/escursiones/proponente/'

  constructor(private http: HttpClient) { }

  getEscursioneById(id: number): Observable<any> {
    return this.http.get(`${this.baseUrl}/${id}`);
  }

  createEscursione(escursione: any): Observable<any> {
    console.log(escursione);
    return this.http.post(this.baseUrl, escursione);
  }

  updateEscursione(id: number, value: any): Observable<any> {
    return this.http.put(`${this.baseUrl}/${id}`, value);
  }

  searchEscursione(citta: string): Observable<Escursione[]> {
    return this.http.get<Escursione[]>(this.baseUrl3+citta);
  }


  deleteEscursione(id: number): Observable<any> {
    return this.http.delete(`${this.baseUrl}/${id}`);
  }

  getEscursionesList(): Observable<any> {
    return this.http.get(this.baseUrl1);
  }

  getEscursionenonevasa(): Observable<any> {
    return this.http.get(this.baseUrl2);
  }


  getescursionebyProponente(proponente: string): Observable<Escursione[]> {
    return this.http.get<Escursione[]>(this.url4+proponente);
  }

  getEscursionesByAge(age: string): Observable<any> {
    return this.http.get(`${this.baseUrl}/age/${age}`);
  }

  deleteAll(): Observable<any> {
    return this.http.delete(this.baseUrl);
  }
}
