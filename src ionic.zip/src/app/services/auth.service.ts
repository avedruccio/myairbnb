import { Injectable } from '@angular/core';
import { User } from '../model/user';
import { Observable } from 'rxjs';
import { HttpHeaders, HttpClient } from '@angular/common/http';


interface myData {
  success: boolean;
  message: string;
}

@Injectable({
  providedIn: 'root'
})


export class AuthService {
  readonly rootUrl = 'http://localhost/api/auth.php';
  
  private baseUrl = 'http://localhost:8080/api/users';
  url2 = 'http://localhost:8080/user/getAll';
  url3 = 'http://localhost:8080/api/users/login/';

  httpOptions = {
    headers: new HttpHeaders({
      'Content-Type':  'application/json',
    })
   };

  private loggedInStatus = false;

  
  constructor(private http: HttpClient) { }

  setLoggedIn(value: boolean) {
    this.loggedInStatus = value;
  }

  get isLoggedIn() {
    return this.loggedInStatus;
  }

  getUserDetails(username, password) {
    return this.http.post<myData>(this.rootUrl, {
      username,
      password
    });
  }
  
  createUser(user: any): Observable<any> {
    console.log(user);
    return this.http.post(this.baseUrl, user);
  }
 

  checkuser(mail: string, password: string): Observable<User> {
    return this.http.get<User>(this.url3 + mail + '/' + password);
  }


  getutenti(): Observable<User[]> {
    return this.http.get<User[]>(this.url2);
}

}
