import { TestBed } from '@angular/core/testing';

import { CommentoripostaService } from './commentoriposta.service';

describe('CommentoripostaService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: CommentoripostaService = TestBed.get(CommentoripostaService);
    expect(service).toBeTruthy();
  });
});
