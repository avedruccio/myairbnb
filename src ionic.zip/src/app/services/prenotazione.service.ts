import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Prenotazione } from '../model/prenotazione';

@Injectable({
  providedIn: 'root'
})
export class PrenotazioneService {
  
  private baseUrl = 'http://localhost:8080/api/prenotazioni';
  private baseUrl2 = 'http://localhost:8080/api/prenotazioni/mailuser/';

  constructor(private http: HttpClient) {}

  createPrenotazione(prenotazione: any): Observable<any> {
  
    return this.http.post(this.baseUrl, prenotazione);
  }

  showPrenotazioni(mailuser: any): Observable<any> {
    return this.http.get(`${this.baseUrl}/mailuser/${mailuser}`);
  }

}
