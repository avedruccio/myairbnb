import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import {observable, Observable} from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class TiposervizioService {

  private baseUrl12 = 'http://localhost:8080/api/tiposervizios';
  private baseUrl = 'http://localhost:8080/api/tiposervizios/visible/0';

  constructor(private http: HttpClient) { }

  getTiposervizio(id: number): Observable<any> {
    return this.http.get(`${this.baseUrl}/${id}`);
  }

  createTiposervizio(tiposervizio: any): Observable<any> {
    console.log(tiposervizio);
    return this.http.post(this.baseUrl, tiposervizio);
  }

  updateTiposervizio(id: number, value: any): Observable<any> {
    return this.http.put(`${this.baseUrl}/${id}`, value);
  }

  deleteTiposervizio(id: number): Observable<any> {
    return this.http.delete(`${this.baseUrl}/${id}`);
  }

  getTiposerviziosList(): Observable<any> {
    console.log(observable)
    return this.http.get(this.baseUrl12);
  }
  getTiposerviziosList1(): Observable<any> {
    console.log(observable)
    return this.http.get(this.baseUrl);
  }

  getTiposerviziosByAge(age: string): Observable<any> {
    return this.http.get(`${this.baseUrl}/age/${age}`);
  }

  deleteAll(): Observable<any> {
    return this.http.delete(this.baseUrl);
  }


}
