import { TestBed } from '@angular/core/testing';

import { TiposervizioService } from './tiposervizio.service';

describe('TiposervizioService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: TiposervizioService = TestBed.get(TiposervizioService);
    expect(service).toBeTruthy();
  });
});
