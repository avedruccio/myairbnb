import { TestBed } from '@angular/core/testing';

import { EscursioneService } from './escursione.service';

describe('EscursioneService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: EscursioneService = TestBed.get(EscursioneService);
    expect(service).toBeTruthy();
  });
});
