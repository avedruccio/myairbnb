import { TestBed } from '@angular/core/testing';

import { CommentoService } from './commento.service';

describe('CommentoService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: CommentoService = TestBed.get(CommentoService);
    expect(service).toBeTruthy();
  });
});
