import { Injectable } from '@angular/core';
import {Observable} from 'rxjs';
import {HttpClient} from '@angular/common/http';
import { Auto } from '../model/auto';

@Injectable({
  providedIn: 'root'
})
export class AutoService {
  private baseUrl = 'http://localhost:8080/api/autos/';
  private baseUrl2 = 'http://localhost:8080/api/autos/evasa/1';
  private baseUrl1 = 'http://localhost:8080/api/autos/evasa/0';
  private baseUrl3 = 'http://localhost:8080/api/autos/citta/';
  private baseUrl4 = 'http://localhost:8080/api/autos/proponente/';
  constructor(private http: HttpClient) { }

  getAutobyId(id:string): Observable<any> {
    return this.http.get(`${this.baseUrl}/${id}`);
  
}

  createAuto(auto: any): Observable<any> {
    console.log(auto);
    return this.http.post(this.baseUrl, auto);
  }

  getAutoList(): Observable<any> {
    return this.http.get(this.baseUrl2);
  }

  getAutononevase(): Observable<any> {
    return this.http.get(this.baseUrl1);
  }

  searchAuto(citta: string): Observable<Auto[]> {
    return this.http.get<Auto[]>(this.baseUrl3+citta);
  }

  getautobyProponente(proponente: string): Observable<Auto[]> {
    return this.http.get<Auto[]>(this.baseUrl4+proponente);
  }



  updateAuto(id: number, value: any): Observable<any> {
    return this.http.put(`${this.baseUrl}/${id}`, value);
  }

  deleteAuto(id: number): Observable<any> {
    return this.http.delete(`${this.baseUrl}/${id}`);
  }



}
