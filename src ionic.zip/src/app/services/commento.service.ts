import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';


@Injectable({
  providedIn: 'root'
})
export class CommentoService {
  private baseUrl = 'http://localhost:8080/api/commenti';

  constructor(private http: HttpClient) { }

  createCommento(commento: any): Observable<any> {
    console.log(commento);
    return this.http.post(this.baseUrl, commento);
  }


SearchCommentoforTypeofService(idtiposervizio:any): Observable<any>{
  return this.http.get(`${this.baseUrl}/idtiposervizio/${idtiposervizio}`);
}


}
 