import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
@Injectable({
  providedIn: 'root'
})
export class ServizioService {
  private baseUrl = 'http://localhost:8080/api/servizis';
  private baseUrl5 = 'http://localhost:8080/api/servizis/citta';
  private baseUrl1 = 'http://localhost:8080/api/servizis/evasa/0';
  private baseUrl2 = 'http://localhost:8080/api/servizis/evasa/1';
  private baseUrl4 = 'http://localhost:8080/api/servizis/proponente';

  constructor(private http: HttpClient) { }

  getServizio(id: number): Observable<any> {
    return this.http.get(`${this.baseUrl}/${id}`);
  }


  getServizioByCittaAndNomeservizio(citta:string,nomeservizio:string): Observable<any> {
    return this.http.get(`${this.baseUrl}/${citta}/${nomeservizio}`);
  }



  getServizi(): Observable<any> {
    return this.http.get(`${this.baseUrl2}`);
  }

  
  createServizio(servizio: any): Observable<any> {
    console.log(servizio);
    return this.http.post(this.baseUrl, servizio);
  }

  updateServizio(id: number, value: any): Observable<any> {
    return this.http.put(`${this.baseUrl}/${id}`, value);
  }
  getServizioUser(prononente: string): Observable<any> {
    return this.http.get(`${this.baseUrl4}/${prononente}`);
  }

  getServiziononevase(): Observable<any> {
    return this.http.get(this.baseUrl1);
  }
  deleteServizio(id: number): Observable<any> {
    return this.http.delete(`${this.baseUrl}/${id}`);
  }

  deleteservizio(id: number): Observable<any> {
    return this.http.delete(`${this.baseUrl}/${id}`);
  }

  getserviziosList(): Observable<any> {
    return this.http.get(this.baseUrl);
  }

  getserviziosByCitta(place: string): Observable<any> {
    return this.http.get(`${this.baseUrl5}/${place}`);
  }

  deleteAll(): Observable<any> {
    return this.http.delete(this.baseUrl);
  }
}
