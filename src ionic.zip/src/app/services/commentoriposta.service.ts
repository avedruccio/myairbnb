import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class CommentoripostaService {
 private baseUrl = 'http://localhost:8080/api/commentirisposta';

  constructor(private http: HttpClient) { }

  createCommentoRisposta(commentorisposta: any): Observable<any> {
    console.log(commentorisposta);
    return this.http.post(this.baseUrl, commentorisposta);
  }


SearchCommentoforTypeofService(idtiposervizio:any): Observable<any>{
  return this.http.get(`${this.baseUrl}/idtiposervizio/${idtiposervizio}`);
}

getRisposteList(): Observable<any> {
  return this.http.get(this.baseUrl);
}



}
