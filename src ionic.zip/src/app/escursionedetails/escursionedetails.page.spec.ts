import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EscursionedetailsPage } from './escursionedetails.page';

describe('EscursionedetailsPage', () => {
  let component: EscursionedetailsPage;
  let fixture: ComponentFixture<EscursionedetailsPage>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EscursionedetailsPage ],
      schemas: [CUSTOM_ELEMENTS_SCHEMA],
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EscursionedetailsPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
