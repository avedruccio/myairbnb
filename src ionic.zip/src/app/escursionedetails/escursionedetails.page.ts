import { AfterContentInit, Component, OnInit, ViewChild} from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Commento } from '../model/commento';
import { CommentoService } from '../services/commento.service';
import { CommentoripostaService } from '../services/commentoriposta.service';
import { CommentoRisposta } from '../model/commentorisposta';
import { AlertController } from '@ionic/angular';

declare var google;

@Component({
  selector: 'app-escursionedetails',
  templateUrl: './escursionedetails.page.html',
  styleUrls: ['./escursionedetails.page.scss'],
})
export class EscursionedetailsPage implements OnInit {
  map;
  public ci: string;
  public co: string;
  public idesc: string;
  public nome: string;
  public citta: string;
  public descrizione: string;
  public durata: string;
  public posti: string;
  public image: string;
  public indirizzo: string;
  public indirizzoarr: string;
  public carr: string;
  public proponente: string;
  public prezzo: string;
  user:String
  risposte:CommentoRisposta[];
  commenti:Commento[];
  commento: Commento = new Commento();
  submitted = false;
 
 public numstelle:string;
 @ViewChild('mapElement', {static: true})  mapElement;
  lng: number;
  lat: number;
  lngarr: number;
  latarr: number;
  constructor(public alertController: AlertController,private commentoripsostaservice:CommentoripostaService,private commentoservice: CommentoService,private router: Router,private route: ActivatedRoute) { 
    this.ci =this.route.snapshot.paramMap.get('ci') ;
    this.co =this.route.snapshot.paramMap.get('co') ;
    this.idesc =this.route.snapshot.paramMap.get('id') ;
    this.citta =this.route.snapshot.paramMap.get('citta') ;
    this.descrizione =this.route.snapshot.paramMap.get('descrizione') ;
    this.durata =this.route.snapshot.paramMap.get('durata') ;
    this.nome =this.route.snapshot.paramMap.get('nome') ;
    this.posti =this.route.snapshot.paramMap.get('posti') ;
    this.prezzo =this.route.snapshot.paramMap.get('prezzogiornaliero') ;
    this.image =this.route.snapshot.paramMap.get('image') ;
    this.indirizzo =this.route.snapshot.paramMap.get('indirizzo') ;
    this.indirizzoarr =this.route.snapshot.paramMap.get('indirizzoarr') ;
    this.carr ="empty"
    this.proponente =this.route.snapshot.paramMap.get('proponente') ;
    this.lng=+this.indirizzo.split('-')[1]
    this.lat=+this.indirizzo.split('-')[0]

    this.lngarr=+this.indirizzoarr.split('-')[1]
    this.latarr=+this.indirizzoarr.split('-')[0]
  }

  ngOnInit() {
   this.user=sessionStorage.getItem('username')
    this.commentoservice.SearchCommentoforTypeofService(3).subscribe( data => {
    this.commenti = data;    })
    
    this.commentoripsostaservice.getRisposteList().subscribe( data1 => {
      this.risposte =data1;    })

  }

  ngAfterContentInit(): void {
    this.map = new google.maps.Map(
    this.mapElement.nativeElement,  
        {
          center: {lat: -34.397, lng: 150.644},
          zoom: 8
        });

        const pos = {
          lat: this.lat,
          lng: this.lng
        };

        const pos2 = {
          lat: this.latarr,
          lng: this.lngarr
        };
        this.map.setCenter(pos);

       
        const marker = new google.maps.Marker({
          position: pos, //marker position
          map: this.map, //map already created
          title: this.citta,
        
        });

        const marker2 = new google.maps.Marker({
          position: pos2, //marker position
          map: this.map, //map already created
          title: this.carr,
        
        });

        const contentString =this.citta ;
    const infowindow = new google.maps.InfoWindow({
      content: contentString,
      maxWidth: 400
    });
    marker.addListener('click', function() {
      infowindow.open(this.map, marker);
    });
 
    const contentString2 =this.carr ;
    const infowindow2 = new google.maps.InfoWindow({
      content: contentString,
      maxWidth: 400
    });
    marker.addListener('click', function() {
      infowindow.open(this.map, marker2);
    });

  }
 async booking(idesc,ci,co,citta,descrizione,durata,nome,posti,prezzo,image,indirizzo,indirizzoarr,carr,proponente){
    console.log(proponente)

    if ( this.user == 'GUEST') {
      const alert = await this.alertController.create({
       header: 'ATTENZIONE',
       message: 'Per effettuare la prenotazione è necessario effettuare la registrazione',
       buttons: ['OK'],
   });
 
                            await alert.present();
                            const result = await alert.onDidDismiss();
                            console.log(result);
 
   } else if (this.ci == 'empty') { const alert = await this.alertController.create({
       header: 'ATTENZIONE',
       message: 'Verifica la disponibilità nelle date che cerchi',
       buttons: ['OK'],
   });
 
       await alert.present();
       const result = await alert.onDidDismiss();
       console.log(result);
      }else{

        this.router.navigate(["prenota-escursione",idesc,ci,co,citta,descrizione,durata,nome,posti,prezzo,image,indirizzo,indirizzoarr,carr,proponente]);
      }
      }
      newCommeno(): void {
        this.submitted = false;
        this.commento = new Commento();
      }
      
      
      checkValue(event){ this.numstelle=event.detail.value}
      
      async AddComment() {
        if (this.user == 'GUEST') { 
          const alert = await this.alertController.create({
           header: 'ATTENZIONE',
           message: 'Per inserire un commento è necessario effettuare la registrazione',
           buttons: ['OK'],
       });
     
           await alert.present();
           const result = await alert.onDidDismiss();
           console.log(result);
          } else if (this.numstelle == undefined) {    
            const alert = await this.alertController.create({
           header: 'ATTENZIONE',
           message: 'Aggiungi numero di stelle',
           buttons: ['OK'],
       });
     
           await alert.present();
           const result = await alert.onDidDismiss();
           console.log(result); }
         else{
        this.commento.mailuser=""+this.proponente;
        this.commento.idtiposervizio=3;
        this.commento.id_servizio_commentato=+this.idesc
        this.commento.stelle=+this.numstelle
        console.log(this.numstelle)
        this.commentoservice.createCommento(this.commento)
          .subscribe(
            data => {
              console.log(data);
              this.submitted = true;
            },
            error => console.log(error));
        this.commento = new Commento();
      }}
      
      
}
