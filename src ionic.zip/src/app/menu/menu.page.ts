import { Component, OnInit } from '@angular/core';
import { NavController } from '@ionic/angular';
import { Router, RouterEvent } from '@angular/router';

@Component({
  selector: 'app-menu',
  templateUrl: './menu.page.html',
  styleUrls: ['./menu.page.scss'],
})

export class MenuPage implements OnInit {
  
  
  pages=[
    {title:'firstpage',
  url:'/firstpage'},
  {title:'secondpage',
  url:'/register'}];



  selectedPath=''
  constructor(public NavCtrl: NavController,private router: Router) {  
    this.router.events.subscribe((event:RouterEvent)=>{
      this.selectedPath=event.url;

    })
  }

  ngOnInit() {
  }

}
