import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PrenotaEscursionePage } from './prenota-escursione.page';

describe('PrenotaEscursionePage', () => {
  let component: PrenotaEscursionePage;
  let fixture: ComponentFixture<PrenotaEscursionePage>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PrenotaEscursionePage ],
      schemas: [CUSTOM_ELEMENTS_SCHEMA],
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PrenotaEscursionePage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
