import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-mappa',
  templateUrl: './mappa.page.html',
  styleUrls: ['./mappa.page.scss'],
})
export class MappaPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
