import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-detailsauto',
  templateUrl: './detailsauto.page.html',
  styleUrls: ['./detailsauto.page.scss'],
})
export class DetailsautoPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
