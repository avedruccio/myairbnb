import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Routes, RouterModule } from '@angular/router';

import { IonicModule } from '@ionic/angular';

import { ServiziopropostoPage } from './servizioproposto.page';

const routes: Routes = [
  {
    path: '',
    component: ServiziopropostoPage
  }
];

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    RouterModule.forChild(routes)
  ],
  declarations: [ServiziopropostoPage]
})
export class ServiziopropostoPageModule {}
