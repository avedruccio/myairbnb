import { Component } from '@angular/core';
import {Router} from '@angular/router';

@Component({
  selector: 'app-home',
  templateUrl: 'home.page.html',
  styleUrls: ['home.page.scss'],
})
export class HomePage {
pages=[
{
  title:'first page',
    url:'login'
}

]
  constructor(private router: Router) {

  }

  goToRegistrationPage() {
     
      this.router.navigateByUrl('/register');
    }
    
    loginAsGuest() {
      var user = sessionStorage.setItem('username',"GUEST");
      this.router.navigateByUrl('/firstpage');
    }
  

} 
