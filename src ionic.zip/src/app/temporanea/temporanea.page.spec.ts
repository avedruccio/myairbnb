import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TemporaneaPage } from './temporanea.page';

describe('TemporaneaPage', () => {
  let component: TemporaneaPage;
  let fixture: ComponentFixture<TemporaneaPage>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TemporaneaPage ],
      schemas: [CUSTOM_ELEMENTS_SCHEMA],
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TemporaneaPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
