import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-temporanea',
  templateUrl: './temporanea.page.html',
  styleUrls: ['./temporanea.page.scss'],
})
export class TemporaneaPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
