import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ResultAppartamentoPage } from './result-appartamento.page';

describe('ResultAppartamentoPage', () => {
  let component: ResultAppartamentoPage;
  let fixture: ComponentFixture<ResultAppartamentoPage>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ResultAppartamentoPage ],
      schemas: [CUSTOM_ELEMENTS_SCHEMA],
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ResultAppartamentoPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
