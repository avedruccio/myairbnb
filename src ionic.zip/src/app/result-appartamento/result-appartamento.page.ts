import { Component, OnInit, ViewChild } from '@angular/core';
import { Apartment } from '../model/apartment';
import { Router, ActivatedRoute } from '@angular/router';
import { ApartmentService } from '../services/apartment.service';

@Component({
  selector: 'app-result-appartamento',
  templateUrl: './result-appartamento.page.html',
  styleUrls: ['./result-appartamento.page.scss'],
})
export class ResultAppartamentoPage implements OnInit {
  

  stringa:string;

  public place: string;
  public ci: string;
  public co: string;
  public ospiti: string;

  appartamenti: Apartment[];
  appartamento: Apartment;
  constructor(private router: Router,private route: ActivatedRoute,private appartamentoService: ApartmentService) {
  
      this.place =this.route.snapshot.paramMap.get('place') ;
      this.ci =this.route.snapshot.paramMap.get('ci') ;
      this.co =this.route.snapshot.paramMap.get('co') ;
      this.ospiti =this.route.snapshot.paramMap.get('ospiti') ;
      this.appartamentoService.searchApartment(this.place).subscribe(data => {
      this.stringa = JSON.stringify(data);})
      
   }

  ngOnInit() {
    
    this.appartamento = {} as Apartment;

    this.appartamentoService.searchApartment(this.place).subscribe( data => {
     
      this.appartamenti = data;
    })
    
  }
 



  getItems(data){
    console.log(data.nome);
    console.log(data.descrizione);
    console.log(data.posti);
    console.log(data.citta);
    console.log(data.indirizzo);
    console.log(data.id)
    this.router.navigate(["details/",data.id, this.ci, this.co,data.nome,data.citta,data.indirizzo,data.descrizione,data.posti,data.image,data.prezzogiornaliero,data.proponente]);
  }

}
