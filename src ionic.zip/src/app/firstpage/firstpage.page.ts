import { ServizioService } from './../services/servizio.service';
import { ApartmentService } from './../services/apartment.service';
import { Component, OnInit } from '@angular/core';
import {Router} from '@angular/router';
import {NavController} from'@ionic/angular'
import { Apartment } from '../model/apartment';
import { Escursione } from '../model/escursione';
import { EscursioneService } from '../services/escursione.service';
import { Auto } from '../model/auto';
import { AutoService } from '../services/auto.service';
import { NotificaService } from '../services/notifica.service';
import { Notifica } from '../model/notifica';
import { TiposervizioService } from '../services/tiposervizio.service';
import { Tiposervizio } from '../model/tiposervizio';
import { Servizio } from '../model/servizio';

@Component({
  selector: 'app-firstpage',
  templateUrl: './firstpage.page.html',
  styleUrls: ['./firstpage.page.scss'],
  
})
export class FirstpagePage implements OnInit {
  searchQuery: string = '';
  items: string[];
  user:string;
  service: string = "Alloggio";
  appartamenti:Apartment[];
  escursioni: Escursione[];
  automobili: Auto[];
  tiposervizio: Tiposervizio[];
  notifiche:Notifica[];
  notifiche2:Notifica[];
  notifiche3:Notifica[];
 
  servizi:Servizio[];
  tot: number;
  

  constructor( private servizioService: ServizioService,private tiposervizioService: TiposervizioService,private notificaService: NotificaService,private autoservice:AutoService,private escursioneservice: EscursioneService,private apartment:ApartmentService,public NavCtrl: NavController,private router: Router) {  
    
    this.apartment.getAppartamenti().subscribe( data => {
      this.appartamenti = data;    })

      this.escursioneservice.getEscursionesList().subscribe( data1 => {
        this.escursioni = data1; 
       })

       this.autoservice.getAutoList().subscribe( data2 => {
        this.automobili = data2; 
       })
  

       this.tiposervizioService.getTiposerviziosList().subscribe( data4 => {
        this.tiposervizio = data4;
      });
  
  
      this.servizioService.getServizi().subscribe( data3 => {
        this.servizi = data3; 
       })


      }

  launchDetails(event){
 
  this.NavCtrl.navigateForward('details/'+event.path[0].id);
}
  ngOnInit() {
    this.user=sessionStorage.getItem('username')

  

    this.notifiche = [];
    this.notifiche2 = [];
    this.notifiche3 = [];
   


    this.notificaService.getNotificaUser('' + this.user).subscribe( data1 => {
      this.notifiche = data1; 
    
      this.notificaService.getNotificaUser("tutti").subscribe( data2 => {
        this.notifiche2= data2;

      
        this.notifiche3=this.notifiche2.concat(this.notifiche)
       

  });
   });
}


  public search(event) {
    event.preventDefault();
    const target = event.target;
    const place = target.querySelector('#place').value;
    const ci = target.querySelector('#ci').value;
    const co = target.querySelector('#co').value;
    const ospiti = target.querySelector('#ospiti').value;
   console.log(co,ci,place,ospiti)
   this.router.navigate(["resultapp/", place,ci,co,ospiti]);

}
public search3(event) {
  event.preventDefault();
  const target = event.target;
  const place = target.querySelector('#place2').value;
  const ci = target.querySelector('#ci2').value;
  const co = target.querySelector('#co2').value;
  const ospiti = target.querySelector('#ospiti2').value;
 console.log(co,ci,place,ospiti)
 this.router.navigate(["result-auto/", place,ci,co,ospiti]);

}

getItemsServizio(data) {
  console.log(data.nome);
  console.log(data.descrizione);
  console.log(data.bcolor);
  console.log(data.icona);
 // this.router.navigate(['insert-servizio/', data.nome,data.descrizione,data.bcolor,data.icona]);
}

onChange(deviceValue) {
  console.log(deviceValue);
}

public search2(event) {
  event.preventDefault();
  const target = event.target;
  const place = target.querySelector('#place1').value;
  const ci = target.querySelector('#ci1').value;
  const co = target.querySelector('#co1').value;
  const ospiti = target.querySelector('#ospiti1').value;
 
  this.router.navigate(["result-escursione/", place,ci,co,ospiti]);
}



public search5(event,serv) {
  event.preventDefault();
  const target = event.target;
  const place = target.querySelector('#place1').value;
  const ci = target.querySelector('#ci1').value;
  const co = target.querySelector('#co1').value;
  const ospiti = target.querySelector('#ospiti1').value;
  const nomeservizio = serv.nome;
  const idtiposervizio = serv.id;
  console.log(serv.nome);
  this.router.navigate(["result-servizio/", place,ci,co,ospiti,nomeservizio,idtiposervizio]);
}
 


  getItems(data){

    this.router.navigate(["details/",data.id,"empty","empty",data.nome,data.citta,data.indirizzo,data.descrizione,data.posti,data.image,data.prezzogiornaliero,data.proponente]);
  }

  getEscursione(data){
    this.router.navigate(["escursionedetails/","empty","empty",data.id,data.citta,data.descrizione,data.durata,data.nome,data.posti,data.prezzogiornaliero,data.image,data.indirizzo,data.indirizzoarr,"empty",data.proponente]);

  }
  getServizio(data,data2){
    this.router.navigate(["serviziodetails/","empty","empty",data.id,data.citta,data.descrizione,data.durata,data.nome,data.posti,data.prezzogiornaliero,data.image,data.indirizzo,data.indirizzoarr,data.proponente,data2.id]);

  }
  ViewNotifiche(){
    this.router.navigate(["view-notifica"]);

  }

getAuto(data){
  this.router.navigate(["autodetails/",data.id,"empty","empty",data.marca,data.targa,data.citta,data.indirizzo,data.modello,data.posti,data.carburante,data.image,data.prezzogiornaliero,data.proponente]);
}







}
