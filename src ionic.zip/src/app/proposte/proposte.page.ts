import { Auto } from './../model/auto';
import { AutoService } from './../services/auto.service';
import { Escursione } from './../model/escursione';
import { ApartmentService } from './../services/apartment.service';
import { Component, OnInit } from '@angular/core';
import { Apartment } from '../model/apartment';
import { EscursioneService } from '../services/escursione.service';
import { Router } from '@angular/router';
import { ServizioService } from '../services/servizio.service';
import { Servizio } from '../model/servizio';
import { TiposervizioService } from '../services/tiposervizio.service';
import { Tiposervizio } from '../model/tiposervizio';

@Component({
  selector: 'app-proposte',
  templateUrl: './proposte.page.html',
  styleUrls: ['./proposte.page.scss'],
})
export class PropostePage implements OnInit {
  cittaapp= [];
  nomeapp= [];
  proponente: string;
  escursioni:Escursione[];
  appartamenti:Apartment[];
  automobili:Auto[];
  servizi:Servizio[];
  tiposervizi:Tiposervizio[];
  constructor( private tiposervizioService:TiposervizioService,private servizioService:ServizioService,private router: Router,private appartamentoservice:ApartmentService,private escursioneservice:EscursioneService,private autoservice:AutoService) { }

  ngOnInit() {
    this.proponente=sessionStorage.getItem('username')
  
    this.appartamentoservice.getAppartamentibyProponente(this.proponente).subscribe( data1 => {
      this.appartamenti = data1;    
    })

   

    this.escursioneservice.getescursionebyProponente(this.proponente).subscribe( data1 => {
      this.escursioni = data1;    
    })


    this.autoservice.getautobyProponente(this.proponente).subscribe( data1 => {
      this.automobili = data1;    
    })

this.servizioService.getServizioUser(this.proponente).subscribe( data4 => {
  this.servizi = data4;    
})



this.tiposervizioService.getTiposerviziosList().subscribe( data5 => {
  this.tiposervizi = data5;    
})
  }


  getAppartamento(app){
    const id= app.id
    const nome=app.nome
    const citta=app.citta
    const ci=app.iniziodisponibilita
    const co=app.finedisponibilita
    const ospiti=app.posti
    const imageprop=app.image
   this.router.navigate(["appartamentoproposto/", id,nome,citta,ci,co,ospiti,imageprop]);
  }
  
 
   
public getAuto(aut) {
 
  const idauto = aut.id
  const marca = aut.marca
  const modello = aut.modello
  const targa = aut.targa
  const carburante = aut.carburante
  const place = aut.citta
  const ci = aut.iniziodisponibilita
  const co = aut.finedisponibilita
  const ospiti = aut.posti
  const imageprop=aut.image

 this.router.navigate(["autoproposta/", idauto,marca,modello,targa,carburante,place,ci,co,ospiti,imageprop]);

}


public getEscursione(esc) {

  const idesc = esc.id
  const nome = esc.nome
  const cittapartenza = esc.citta
  const cittaarrivo =  esc.carr
  const ci = esc.iniziodisponibilita
  const co = esc.finedisponibilita
  const ospiti = esc.posti
  const imageprop=esc.image
 
  this.router.navigate(["escursioneproposta/",idesc, nome,cittapartenza,cittaarrivo,ci,co,ospiti,imageprop]);

     }
    
     public getServizio(serv,idtiposerv) {

      const idserv = serv.id
      const nome = serv.nome
      const citta= serv.citta
      const ci = serv.iniziodisponibilita
      const co = serv.finedisponibilita
      const ospiti = serv.posti
     const idtiposervizio = idtiposerv
     const imageprop=serv.image
     console.log(idserv)
      this.router.navigate(["servizioproposto/",idserv, nome,citta,ci,co,ospiti,idtiposervizio,imageprop]);
    
         }



   }
  



