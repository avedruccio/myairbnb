import { Escursione } from './../model/escursione';
import { Auto } from './../model/auto';
import { ApartmentService } from './../services/apartment.service';
import { Component, OnInit } from '@angular/core';
import { PrenotazioneService } from '../services/prenotazione.service';
import { Prenotazione } from '../model/prenotazione';
import { Apartment } from '../model/apartment';
import { AutoService } from '../services/auto.service';
import { EscursioneService } from '../services/escursione.service';
import { ServizioService } from '../services/servizio.service';
import { Servizio } from '../model/servizio';



@Component({
  selector: 'app-prenotazioni',
  templateUrl: './prenotazioni.page.html',
  styleUrls: ['./prenotazioni.page.scss'],
})

export class PrenotazioniPage implements OnInit {
  cittaapp= [];
  nomeapp= [];
  cittaauto= [];
  cittapartenza= [];
  cittaarrivo= [];
  nomeesc= [];
  modelloauto= [];
  nome:string
  descr = [];
  acquirente: string;
  prenotazioni: Prenotazione[];
  id:string;
  appartamenti:Apartment[];
  automobili:Auto[];
  escursioni:Escursione[];
  servizi:Servizio[];
  constructor(private prenotazioneService: PrenotazioneService,private servizioService: ServizioService, private appartamentoservice:ApartmentService, private autoservice:AutoService,private escursioneservice:EscursioneService) { 
    
   
  }

  ngOnInit() {
    this.acquirente=sessionStorage.getItem('username')
  
    
  this.prenotazioneService.showPrenotazioni(this.acquirente).subscribe( data1 => {
    this.prenotazioni = data1;    
    
  })

   

  this.appartamentoservice.getAppartamenti().subscribe( data => {
    this.appartamenti = data; 
})


this.autoservice.getAutoList().subscribe( data => {
  this.automobili = data; 
})


this.escursioneservice.getEscursionesList().subscribe( data => {
  this.escursioni = data; 
})

this.servizioService.getServizi().subscribe( data => {
  this.servizi = data; 
})



  }


 
  




 
}
