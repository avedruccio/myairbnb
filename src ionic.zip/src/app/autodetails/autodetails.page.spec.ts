import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AutodetailsPage } from './autodetails.page';

describe('AutodetailsPage', () => {
  let component: AutodetailsPage;
  let fixture: ComponentFixture<AutodetailsPage>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AutodetailsPage ],
      schemas: [CUSTOM_ELEMENTS_SCHEMA],
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AutodetailsPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
