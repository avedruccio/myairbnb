import { AfterContentInit, Component, OnInit, ViewChild} from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Commento } from '../model/commento';
import { CommentoService } from '../services/commento.service';
import { CommentoripostaService } from '../services/commentoriposta.service';
import { CommentoRisposta } from '../model/commentorisposta';
import { AlertController } from '@ionic/angular';
declare var google;

@Component({
  selector: 'app-autodetails',
  templateUrl: './autodetails.page.html',
  styleUrls: ['./autodetails.page.scss'],
})
export class AutodetailsPage implements OnInit , AfterContentInit {
  map;
  public idauto: string;
  public ci: string;
  public co: string;
  public targa: string;
  public marca: string;
  public citta: string;
  public modello: string;
  public carburante: string;
  public posti: string;
  public image: string;
  public prezzogiornaliero: string;
  public indirizzo: string;
  public proponente: string;
  commenti:Commento[];
  risposte:CommentoRisposta[];
  commento: Commento = new Commento();
  submitted = false;
 user:String;
 public numstelle:String;
 @ViewChild('mapElement', {static: true})  mapElement;
  lng: number;
  lat: number;

  constructor(public alertController: AlertController,private commentoripsostaservice:CommentoripostaService,private commentoservice: CommentoService,private router: Router,private route: ActivatedRoute) { 
    
    this.idauto =this.route.snapshot.paramMap.get('idauto') ;
    this.ci =this.route.snapshot.paramMap.get('ci') ;
    this.proponente =this.route.snapshot.paramMap.get('proponente') ;
    this.co =this.route.snapshot.paramMap.get('co') ;
    this.marca =this.route.snapshot.paramMap.get('marca') ;
    this.targa =this.route.snapshot.paramMap.get('targa') ;
    this.citta =this.route.snapshot.paramMap.get('citta') ;
    this.indirizzo=this.route.snapshot.paramMap.get('indirizzo') ;
    this.modello =this.route.snapshot.paramMap.get('modello') ;
    this.posti =this.route.snapshot.paramMap.get('posti') ;
    this.carburante =this.route.snapshot.paramMap.get('carburante') ;
    this.image =this.route.snapshot.paramMap.get('image') ;  
    this.prezzogiornaliero =this.route.snapshot.paramMap.get('prezzogiornaliero') ;
    this.lng=+this.indirizzo.split('-')[1]
    this.lat=+this.indirizzo.split('-')[0]
  }

  ngOnInit() {
    this.user=sessionStorage.getItem('username')

    this.commentoservice.SearchCommentoforTypeofService(2).subscribe( data => {
      this.commenti = data;    })

      this.commentoripsostaservice.getRisposteList().subscribe( data1 => {
        this.risposte =data1;    })
  }

 async  booking(idauto,ci,co,marca,targa,citta,indirizzo,modello,posti,carburante,image,prezzogiornaliero,proponente){
    if(this.user=="GUEST"){   const alert = await this.alertController.create({
      header: 'ATTENZIONE',
      message: 'Per effettuare la prenotazione è necessario effettuare la registrazione',
      buttons: ['OK'],
  });

                           await alert.present();
                           const result = await alert.onDidDismiss();
                           console.log(result);

  } else if (this.ci == 'empty') { const alert = await this.alertController.create({
      header: 'ATTENZIONE',
      message: 'Verifica la disponibilità nelle date che cerchi',
      buttons: ['OK'],
  });

      await alert.present();
      const result = await alert.onDidDismiss();
      console.log(result);
    }else if(this.ci=="empty"){alert("verifica la disponibilità nelle date che cerchi");}else{
    this.router.navigate(["prenota-auto",idauto,ci,co,marca,targa,citta,indirizzo,modello,posti,carburante,image,prezzogiornaliero,proponente]);

  }}
  newCommeno(): void {
    this.submitted = false;
    this.commento = new Commento();
  }
  
   
  checkValue(event){ this.numstelle=event.detail.value}
  
  async AddComment() {
    if(this.user=="GUEST"){   const alert = await this.alertController.create({
      header: 'ATTENZIONE',
      message: 'Per inserire un commento è necessario effettuare la registrazione',
      buttons: ['OK'],
  });

      await alert.present();
      const result = await alert.onDidDismiss();
      console.log(result);
    } 
    else if (this.numstelle==undefined){
      const alert = await this.alertController.create({
        header: 'ATTENZIONE',
        message: 'Aggiungi numero di stelle',
        buttons: ['OK'],
    });
  
        await alert.present();
        const result = await alert.onDidDismiss();
        console.log(result);
    }
     else{
    this.commento.mailuser=""+this.user;
    this.commento.idtiposervizio=2;
    this.commento.id_servizio_commentato=+this.idauto
    this.commento.stelle=+this.numstelle
    console.log(this.numstelle)
    this.commentoservice.createCommento(this.commento)
      .subscribe(
        data => {
          console.log(this.numstelle);
          this.submitted = true;
        },
        error => console.log(error));
    this.commento = new Commento();
  }}
  
  ngAfterContentInit(): void {
      this.map = new google.maps.Map(
      this.mapElement.nativeElement,  
          {
            center: {lat: -34.397, lng: 150.644},
            zoom: 8
          });

          const pos = {
            lat: this.lat,
            lng: this.lng
          };

          this.map.setCenter(pos);

         
          const marker = new google.maps.Marker({
            position: pos, //marker position
            map: this.map, //map already created
            title: this.citta,
          
          });
          const contentString = this.citta;
      const infowindow = new google.maps.InfoWindow({
        content: contentString,
        maxWidth: 400
      });
      marker.addListener('click', function() {
        infowindow.open(this.map, marker);
      });

    }

} 
