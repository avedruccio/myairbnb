import { AuthService } from './../services/auth.service';
import { Component, OnInit,ViewChild } from '@angular/core';
import { User } from '../model/user';
import { Router } from '@angular/router';
import { AlertController } from '@ionic/angular';

@Component({
  selector: 'app-register',
  templateUrl: './register.page.html',
  styleUrls: ['./register.page.scss'],
})
export class RegisterPage implements OnInit {
  user: User = new User();
  submitted = false;

  @ViewChild('nome',{static: false}) nome;
  @ViewChild('cognome',{static: false}) cognome;
  @ViewChild('email',{static: false}) email;
  @ViewChild('password',{static: false}) password;
  @ViewChild('datadinascita',{static: false}) datadinascita;
  @ViewChild('telefono',{static: false}) telefono;


  constructor( public alertController: AlertController,private authservice:AuthService,private router: Router) { }

  ngOnInit() {
  }

  newUser(): void {
    this.submitted = false;
    this.user = new User();
  }

async  ok(){
  const alert = await this.alertController.create({
    header: 'COMPLIMENTI',
    message: 'La tua registrazione è avvenuta con successo',
    buttons: ['OK'],
  });

  await alert.present();
  let result = await alert.onDidDismiss();
  console.log(result);
}


  async save(){
    console.log(this.nome.value,this.cognome.value,this.email.value,this.telefono.value,this.datadinascita.value,this.password.value)
    if(this.nome.value==""||this.cognome.value==""||this.email.value==""||this.telefono.value==""||this.datadinascita.value==""||this.password.value==""){   const alert = await this.alertController.create({
      header: 'ATTENZIONE',
      message: 'Compilare correttamente tutti i campi',
      buttons: ['OK'],
    });
  
    await alert.present();
    let result = await alert.onDidDismiss();
    console.log(result);

  
  }else{
    this.user.name=this.nome.value;
    this.user.cognome=this.cognome.value;
    this.user.mail=this.email.value;
    this.user.telefono=this.telefono.value;
    this.user.datadinascita=this.datadinascita.value;
    this.user.password=this.password.value;
    console.log(this.user)
     this.authservice.createUser(this.user)
      .subscribe(
        data => {
          console.log(data);
          this.submitted = true;
          this.ok()
        
          this.router.navigate(['login']);
        },
        error => console.log(error));
    this.user = new User();
      }
    }
    }
