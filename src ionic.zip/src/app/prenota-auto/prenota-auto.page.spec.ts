import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PrenotaAutoPage } from './prenota-auto.page';

describe('PrenotaAutoPage', () => {
  let component: PrenotaAutoPage;
  let fixture: ComponentFixture<PrenotaAutoPage>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PrenotaAutoPage ],
      schemas: [CUSTOM_ELEMENTS_SCHEMA],
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PrenotaAutoPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
