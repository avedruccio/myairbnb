import { Component, OnInit } from '@angular/core';
import { PrenotazioneService } from '../services/prenotazione.service';
import { Router, ActivatedRoute } from '@angular/router';
import moment from 'moment';
import { Prenotazione } from '../model/prenotazione';
import { NotificaService } from '../services/notifica.service';
import { AlertController } from '@ionic/angular';
import { Notifica } from '../model/notifica';
@Component({
  selector: 'app-prenota-auto',
  templateUrl: './prenota-auto.page.html',
  styleUrls: ['./prenota-auto.page.scss'],
})
export class PrenotaAutoPage implements OnInit {
 
  prenotazione: Prenotazione = new Prenotazione();
  notifica: Notifica = new Notifica();
  submitted = false;
  public nome: string;
  public citta: string;
  public carburante: string;
  public marca: string;
  public modello: string;
  public posti: string;
  public image: string;
  public indirizzo:string;
  public prezzogiornaliero: string;
  public  acquirente :string
  public  ci : string //cambiare in string per far partire l'app
  public  co : string  //cambiare in string per far partire l'app
  public  targa :string
  public idauto:string
  public prodotto:number
  public proponente:string
  firstDate: any
  secondDate: any
  diffInDays: number

 product:any
  constructor(public alertController: AlertController,private prenotazioneService: PrenotazioneService,private router: Router,private route: ActivatedRoute,private  notificaservice: NotificaService) {
   
    this.idauto =this.route.snapshot.paramMap.get('idauto') ;
    this.ci =this.route.snapshot.paramMap.get('ci') ;
    this.co =this.route.snapshot.paramMap.get('co') ;
    this.proponente =this.route.snapshot.paramMap.get('proponente') ;
    this.marca =this.route.snapshot.paramMap.get('marca') ;
    this.targa =this.route.snapshot.paramMap.get('targa') ;
    this.citta =this.route.snapshot.paramMap.get('citta') ;
    this.indirizzo =this.route.snapshot.paramMap.get('indirizzo') ;
    this.modello =this.route.snapshot.paramMap.get('modello') ;
    this.posti =this.route.snapshot.paramMap.get('posti') ;
    this.carburante =this.route.snapshot.paramMap.get('carburante') ;
    this.image =this.route.snapshot.paramMap.get('image') ;
    this.prezzogiornaliero =this.route.snapshot.paramMap.get('prezzogiornaliero') ;

    this.firstDate = moment(this.route.snapshot.paramMap.get('co'));
    this.secondDate = moment(this.route.snapshot.paramMap.get('ci'));
    this.diffInDays = Math.abs(this.firstDate.diff(this.secondDate, 'days')); 
    this.prodotto=this.diffInDays*(+this.prezzogiornaliero)
   }

  ngOnInit() {
    this.acquirente=sessionStorage.getItem('username')
  }


  async ok(){const alert = await this.alertController.create({
    header: 'COMPLIMENTI',
    message: 'Prenotazione effettuata con successo',
    buttons: ['OK'],
});

    await alert.present();
    const result = await alert.onDidDismiss();
    console.log(result);}



  save() {
   
    
    this.prenotazione.mailuser=""+this.acquirente;
    this.prenotazione.checkin=this.ci;
    this.prenotazione.checkout=this.co;
    this.prenotazione.metodopagamento="carta di credito";
    this.prenotazione.id_tiposervizio=2;
    this.prenotazione.id_servizio_prenotato=this.idauto;
    this.prenotazione.totale=this.prodotto;
    this.prenotazioneService.createPrenotazione(this.prenotazione)
      .subscribe(
        data => {
          console.log(data);
          this.submitted = true;
          this.ok();
        },
        error => console.log(error));
    this.prenotazione = new Prenotazione();
  }
  createNotificaPrenotazioneAuto() {
    this.notifica.emailutente = this.proponente;
    this.notifica.vista = 'assets/image/book.png';
    console.log(this.proponente)
    this.notifica.titolo = '' + 'La tua auto " ' +this.marca+' '+this.modello +  ' " è stata Prenotata da '+ this.acquirente+' dal '+this.ci+' al '+ this.co;
  
    this.notificaservice.createNotifica(this.notifica)
      .subscribe(
        data => {
          console.log(data);
          this.submitted = true;
        },
        error => console.log(error));
    this.notifica = new Notifica();  }



}
