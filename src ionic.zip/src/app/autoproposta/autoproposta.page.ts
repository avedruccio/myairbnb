import { Component, OnInit } from '@angular/core';
import { CommentoRisposta } from '../model/commentorisposta';
import { Commento } from '../model/commento';
import { Apartment } from '../model/apartment';
import { CommentoripostaService } from '../services/commentoriposta.service';
import { CommentoService } from '../services/commento.service';
import { Router, ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-autoproposta',
  templateUrl: './autoproposta.page.html',
  styleUrls: ['./autoproposta.page.scss'],
})
export class AutopropostaPage implements OnInit {
  public idaut: string;
  public marca: string;
  public citta: string;
  public modello: string;
  public targa: string;
  public carburante: string;
  public ci: string;
  public co: string;
  public ospiti: string;
  submitted = false;
  commentorisposta:CommentoRisposta  = new CommentoRisposta();imageprop: string;
;
  commenti:Commento[];
  appartamenti: Apartment[];
  appartamento: Apartment;
  risposte:CommentoRisposta[];
  idcomm: string;
  user:String;
 
  constructor(private commentoripsostaservice:CommentoripostaService,private commentoservice: CommentoService,private router: Router,private route: ActivatedRoute) {
    this.idaut =this.route.snapshot.paramMap.get('id') ; 
    this.marca =this.route.snapshot.paramMap.get('marca') ;
    this.modello =this.route.snapshot.paramMap.get('modello') ;
    this.targa =this.route.snapshot.paramMap.get('targa') ;
    this.carburante =this.route.snapshot.paramMap.get('carburante') ;
    this.citta =this.route.snapshot.paramMap.get('place') ;
    this.ci =this.route.snapshot.paramMap.get('ci') ;
    this.co =this.route.snapshot.paramMap.get('co') ;
    this.ospiti =this.route.snapshot.paramMap.get('ospiti') ;
    this.imageprop =this.route.snapshot.paramMap.get('imageprop') ;
   }

  ngOnInit() {
    
    this.user=sessionStorage.getItem('username')

    this.commentoservice.SearchCommentoforTypeofService(2).subscribe( data => {
      this.commenti = data;    })


    this.commentoripsostaservice.getRisposteList().subscribe( data1 => {
      this.risposte =data1;    })
  }
  
  rispcommento(comm){

    this.commentorisposta.mailuser=this.user;
    this.commentorisposta.idtiposervizio=2;
    this.commentorisposta.id_servizio_commentato=+this.idaut
    this.commentorisposta.id_commento_risp=+comm.id
    this.commentoripsostaservice.createCommentoRisposta(this.commentorisposta)
      
    .subscribe(
        data => {
          console.log(data);
          this.submitted = true;
        },
        error => console.log(error));
    this.commentorisposta = new CommentoRisposta();
  }
}
