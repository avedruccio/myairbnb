import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AutopropostaPage } from './autoproposta.page';

describe('AutopropostaPage', () => {
  let component: AutopropostaPage;
  let fixture: ComponentFixture<AutopropostaPage>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AutopropostaPage ],
      schemas: [CUSTOM_ELEMENTS_SCHEMA],
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AutopropostaPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
