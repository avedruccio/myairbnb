import { Component, OnInit } from '@angular/core';
import { Notifica } from '../model/notifica';
import { NotificaService } from '../services/notifica.service';

@Component({
  selector: 'app-view-notifica',
  templateUrl: './view-notifica.page.html',
  styleUrls: ['./view-notifica.page.scss'],
})
export class ViewNotificaPage implements OnInit {
  notifiche: Notifica[];
  notifica: Notifica;
  utente: string;
  notifiche2: Notifica[];
  constructor(private notificaService: NotificaService) { }

  ngOnInit() {
    this.utente = sessionStorage.getItem('username');



    this.notificaService.getNotificaUser('' + this.utente).subscribe( data1 => {
      this.notifiche = data1; });


      this.notificaService.getNotificaUser('tutti').subscribe( data1 => {
        this.notifiche2 = data1;
    });

}
  
deleteNotifica(notifica) {
  this.notificaService.deleteNotifica(notifica.id)
    .subscribe(
      data => {
        console.log(data);
     
      },
      error => console.log(error));
}
  
}
