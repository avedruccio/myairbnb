import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Routes, RouterModule } from '@angular/router';

import { IonicModule } from '@ionic/angular';

import { EscursionepropostaPage } from './escursioneproposta.page';

const routes: Routes = [
  {
    path: '',
    component: EscursionepropostaPage
  }
];

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    RouterModule.forChild(routes)
  ],
  declarations: [EscursionepropostaPage]
})
export class EscursionepropostaPageModule {}
