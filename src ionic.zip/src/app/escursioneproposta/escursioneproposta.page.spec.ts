import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EscursionepropostaPage } from './escursioneproposta.page';

describe('EscursionepropostaPage', () => {
  let component: EscursionepropostaPage;
  let fixture: ComponentFixture<EscursionepropostaPage>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EscursionepropostaPage ],
      schemas: [CUSTOM_ELEMENTS_SCHEMA],
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EscursionepropostaPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
