import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { CommentoRisposta } from '../model/commentorisposta';
import { CommentoripostaService } from '../services/commentoriposta.service';
import { CommentoService } from '../services/commento.service';
import { Commento } from '../model/commento';

@Component({
  selector: 'app-escursioneproposta',
  templateUrl: './escursioneproposta.page.html',
  styleUrls: ['./escursioneproposta.page.scss'],
}) 
export class EscursionepropostaPage implements OnInit {
  submitted = false;
  public idesc: string;
  public nome: string;
  public cittapartenza: string;
  public cittaarrivo: string;
  public ci: string;
  public co: string;
  public ospiti: string;
  commenti:Commento[];
  risposte:CommentoRisposta[];
  idcomm: string;
  user:String;
  commentorisposta:CommentoRisposta  = new CommentoRisposta();
  imageprop: string;
  constructor(private commentoripsostaservice:CommentoripostaService,private commentoservice: CommentoService,private router: Router,private route: ActivatedRoute) { 
    
    this.idesc =this.route.snapshot.paramMap.get('id') ; 
    this.nome =this.route.snapshot.paramMap.get('nome') ;
    this.cittapartenza =this.route.snapshot.paramMap.get('cittapartenza') ;
    this.cittaarrivo =this.route.snapshot.paramMap.get('cittaarrivo') ;
    this.ci =this.route.snapshot.paramMap.get('ci') ;
    this.co =this.route.snapshot.paramMap.get('co') ;
    this.ospiti =this.route.snapshot.paramMap.get('ospiti') ;
    this.imageprop =this.route.snapshot.paramMap.get('imageprop') ;



  }
  
  ngOnInit() {
  

    this.user=sessionStorage.getItem('username')

    this.commentoservice.SearchCommentoforTypeofService(3).subscribe( data => {
      this.commenti = data;    })


    this.commentoripsostaservice.getRisposteList().subscribe( data1 => {
      this.risposte =data1;    })

  }
  rispcommento(comm){

    this.commentorisposta.mailuser=this.user;
    this.commentorisposta.idtiposervizio=3;
    this.commentorisposta.id_servizio_commentato=+this.idesc
    this.commentorisposta.id_commento_risp=+comm.id
    this.commentoripsostaservice.createCommentoRisposta(this.commentorisposta)
      
    .subscribe(
        data => {
          console.log(data);
          this.submitted = true;
        },
        error => console.log(error));
    this.commentorisposta = new CommentoRisposta();
  }

}
